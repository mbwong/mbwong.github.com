(* 
 * ASSIGNMENT DESCRIPTION:
 * 
 * After the first week of cs51 you notice that there is something strange about
 * the teaching staff (including Prof. Morrisett).  They seem enchanted by cute
 * pictures of cats which have been labeled with strange captions.  In hopes of
 * making some easy money, you decide to create an auction system which contains
 * game mechanics that will exploit the teaching staff's affinity for cat
 * pictures.
 * 
 * Your auction system will contain the following logic:
 * - There are a fixed number of cat pictures that members of your auction
 *   system can "own".
 * - Ownership is a purely virtual idea and is purchased using virtual currency.
 * - The teaching staff is stupid enough to spend real money to virtually "own"
 *   pictures of cats.  However, all transactions in the system deal with
 *   virtual credits as currency.
 * - All cat pictures are initially owned by "the house" (which is you) and will
 *   sell for 100 credits.
 * - After a cat picture is purchased, it becomes "owned" by the purchaser, and
 *   its price is then inflated by a factor of two (doubled).
 * - You will charge a 50% tax on all purchases.  For example, a purchase of 200
 *   credits will give the house 100 credits and the seller 100 credits.
 * - A member may buy any cat picture from any other member (or from "the
 *   house") at any time.  Consent from the owner is not required for a purchase
 *   to take place.
 * - A member may sell any cat picture he "owns" back to the house for 50
 *   credits.
 *
 * Your auction system will support the following commands:
 * - list members
 * - list cat_pictures
 * - show highest_priced_cat_picture
 *
 * - add_credits <member-name> <amount>
 * - buy_cat_picture <member-name> <cat-picture-name>
 * - sell_cat_picture <member-name> <cat-picture-name>
 *)

(*
 * PART 1: Member Data
 * 
 * We will identify members of our auction system by their name.  We must also
 * track how much virtual currency they have.
 * 
 * To be complete, we will store a name prefix, first name, middle name, last
 * name, name suffix, and credits balance.
 *)

type member = { 
  name_prefix : string ;
  first_name : string ;
  middle_name : string ;
  last_name : string ;
  name_suffix : string ;

  credits : int ;
} ;;

(*
 * The first operation we want to support is to list the members of the system.
 * However, there are privacy concerns with revealing the full names of other
 * members.  We want to display a generated nickname from each user's name
 * information.
 * 
 * You must write a nickname function which takes a member structure and returns
 * a coded nickname.  Because Snoop Dogg is a big investor in your auction
 * startup, you will be generating names with him in mind.  Here are the rules
 * for nickname generation:
 * 
 * - Use the full prefix and suffix of the name.
 * - Abreviate the first and middle names by using just the first letter of each
 *   followed by a ".".
 * - Obscure the last name by taking the first letter and appending "izzle" to it.
 * - There are a few special cases for the last name obsfuscation:
 *   + A last name starting with 'A' should be obsfuscated to "Abrakadizzle"
 *   + A last name starting with 'E' should be obsfuscated to "Extra Fly Fizzle"
 *   + A last name starting with 'I' should be obsfuscated to "Izzle My Nizzle"
 *   + A last name starting with 'O' should be obsfuscated to "O. M. Gizzle"
 *   + A last name starting with 'U' should be obsfuscated to "Ugly McNizzle"
 *
 * You can assume that all members have non-empty first, middle, and last names.
 * You can assume that all last names start with capital letters.
 *)

let string_of_char = String.make 1

let member_nickname : member -> string =
  fun member ->
    let first_initial = string_of_char(Char.uppercase member.first_name.[0]) ^ "." in
    let middle_initial = string_of_char (Char.uppercase member.middle_name.[0]) ^ "." in
    let last_initial = 
      match member.last_name.[0] with
      | 'A' -> "Abrakadizzle"
      | 'E' -> "Extra Fly Fizzle"
      | 'I' -> "Izzle My Nizzle"
      | 'O' -> "O. M. Gizzle"
      | 'U' -> "Ugh McNizzle"
      | c -> string_of_char (Char.uppercase c) ^ "izzle"
      in
    member.name_prefix ^ 
    (if String.length member.name_prefix == 0 then "" else " ") ^
    first_initial ^ 
    " " ^ 
    middle_initial ^ 
    " " ^ 
    last_initial ^
    (if String.length member.name_suffix == 0 then "" else " ") ^
    member.name_suffix
;;

assert (member_nickname { 
  name_prefix = "Mr" ;
  first_name = "Edward" ;
  middle_name = "Charles" ;
  last_name = "Willingham" ;
  name_suffix = "The Third" ;
  credits = 0 ;
} == "Mr E. C. Wizzle The Third") ;;
assert (member_nickname {
  name_prefix = "Professor" ;
  first_name = "John" ;
  middle_name = "Gregory" ;
  last_name = "Morrisett" ;
  name_suffix = "" ;
  credits = 0 ;
} == "Professor J. G. Mizzle") ;;
assert (member_nickname {
  name_prefix = "" ;
  first_name = "James" ;
  middle_name = "Boden" ;
  last_name = "Anderson" ;
  name_suffix = "Esquire" ;
  credits = 0 ;
} == "J. B. Abrakadizzle Esquire") ;;

let rec list_member_nicknames : member list -> string list = 
  fun member_list -> 
    match member_list with
    | [] -> []
    | m :: ms -> member_nickname m :: list_member_nicknames ms
;;

(* 
 * We also want to support finding a member based on their first and last names.
 * First and last names are considered to be unique identifiers for a member in
 * our system.
 *)

let matches_member_name : (string * string) -> member -> bool =
  fun member_name member -> 
    let (first_name, last_name) = member_name in
    first_name == member.first_name && last_name == member.last_name
;;
     
let rec find_member_by_name : (string * string) -> member list -> member option =
  fun member_name member_list ->
    match member_list with
    | [] -> None
    | m :: ms -> 
        if matches_member_name member_name m
        then Some m 
        else find_member_by_name member_name ms
;;

(*
 * We will often need to update a record for a member.  This can be done by
 * replacing the old record with a new one.
 *)

let rec replace_member : member -> member list -> member list =
  fun member member_list ->
    match member_list with
    | [] -> []
    | m :: ms -> 
        if m.first_name == member.first_name && m.last_name == member.last_name
        then member :: ms
        else m :: replace_member member ms

(* 
 * There are two primary operations for members: buying credits and using
 * credits.  Because we do not allow members to carry a negative balence of
 * credits, we must allow for the act of removing credits to "fail" if
 * someone has insufficient funds.
 *)

let add_credits_to_member : int -> member -> member =
  fun n member ->
    let n' = member.credits in
    { member with credits = n' + n }
;;

let remove_credits_from_member : int -> member -> member option =
  fun n member ->
    let n' = member.credits in
    if n' - n < 0
    then None
    else Some { member with credits = n' - n }
;;

(*
 * When a cat picture is purchased, the buyer loses credits, and both the seller
 * and the house gain credits.  Remember, the house imposes a 50% tax on all
 * purchases.
 *
 * It is not obvious what transfer_credits does merely from the type signature.
 * Here is a more documented description:
 *
 * transfer_credits deducts the supplied amount from the buyer and gives half
 * the amount to the seller.
 * arguments:
 * - amount
 * - buyer
 * - seller
 * returns:
 * - nothing if the buyer doesn't have enough credits
 * - (updated buyer, updated seller)
 *)
let transfer_credits : int -> member -> member -> (member * member) option =
  fun amount buyer seller ->
    match remove_credits_from_member amount buyer with
    | None -> None
    | Some buyer' -> 
        Some (buyer', add_credits_to_member (amount / 2) seller)
;;

(*
 * PART 2: Cat Picture Data
 *
 * A cat picture in our system will have a name and a link to its picture on the
 * web. We must also track the owner and virtual price of each cat picture.  A
 * cat picture may have no owner, which means it is owned by "the house".
 *)

type cat_picture = {
  name : string ;
  image_url : string ;
  
  owner : (string * string) option ;
  price : int ;
} ;;

(* First we want a nice description of a cat picture to display to our
 * users.  We want our description to be the name of the cat picture followed by
 * its price in brackets
 *)

let cat_picture_description : cat_picture -> string =
  fun cat_picture -> cat_picture.name ^ " [" ^ string_of_int cat_picture.price ^ "]"
;;

assert (cat_picture_description { 
  name = "PancakeBunny" ; 
  image_url = "" ; 
  owner = None ;
  price = 4000
} == "PancakeBunny [4000]") ;;

let rec list_cat_picture_descriptions : cat_picture list -> string list =
  fun cat_picture_list -> 
    match cat_picture_list with
    | [] -> []
    | c :: cs -> cat_picture_description c :: list_cat_picture_descriptions cs
;;

(* 
 * As we did for members, we want to support finding a cat picture by its name.
 * Cat picture names are considered to be unique in our system.
 *)

let matches_cat_picture_name : string -> cat_picture -> bool =
  fun name cat_picture -> 
    name == cat_picture.name
;;

let rec find_cat_picture_by_name : string -> cat_picture list -> cat_picture option =
  fun name cat_picture_list ->
    match cat_picture_list with
    | [] -> None
    | c :: cs -> 
        if matches_cat_picture_name name c 
        then Some c
        else find_cat_picture_by_name name cs
;;

(* An updating function for cat pictures will come in handy later *)
     
let rec replace_cat_picture : cat_picture -> cat_picture list -> cat_picture list =
  fun cat_picture cat_picture_list ->
    match cat_picture_list with
    | [] -> []
    | c :: cs -> 
        if c.name == cat_picture.name
        then cat_picture :: cs
        else c :: replace_cat_picture cat_picture cs
;;

(* 
 * For analytic purposes, we are often interested in what the highest priced
 * cat_picture is.  If there are multiple maximum values, we want to return the
 * first in the list of cat pictures.
 *)

let max_priced_left_bias : cat_picture -> cat_picture -> cat_picture =
  fun c1 c2 -> if c1.price >= c2.price then c1 else c2
;;

let rec find_max_priced_left_bias : cat_picture list -> cat_picture option =
  fun cat_picture_list -> 
    match cat_picture_list with
    | [] -> None
    |  c :: cs -> 
        match find_max_priced_left_bias cs with
        | None -> Some c
        | Some c' -> Some (max_priced_left_bias c c')
;;

(*
 * PART 3: A whole auction system
 * The entire auction system consists of just a list of members and a list of
 * cat pictures.
 *)

type auction = { 
  members : member list ;
  cat_pictures : cat_picture list ;
} ;;

(* These are the top level actions that our system supports *)

(* Note to TFs, these should NOT be written or partially written by students.
 * These definitions should be given in full, and the student should be
 * encouraged to look over them and "get a feeling for what they are doing".
 *)

let list_members : auction -> string list =
  fun auction -> list_member_nicknames auction.members
;;

let list_cat_pictures : auction -> string list =
  fun auction -> list_cat_picture_descriptions auction.cat_pictures
;;

let show_highest_priced : auction -> string option =
  fun auction ->
    match find_max_priced_left_bias auction.cat_pictures with
    | None -> None
    | Some cat_picture -> Some (cat_picture_description cat_picture)
;;

let add_credits : (string * string) -> int -> auction -> auction option =
  fun member_name amount auction ->
    match find_member_by_name member_name auction.members with
    | None -> None
    | Some member ->
        let member' = add_credits_to_member amount member in
        Some { auction with 
          members = replace_member member' auction.members
        }
;;

let buy_cat_picture : string * string -> string -> auction -> auction option =
  fun member_name cat_picture_name auction ->
    match find_member_by_name member_name auction.members with
    | None -> None
    | Some buyer -> 
        match find_cat_picture_by_name cat_picture_name auction.cat_pictures with
        | None -> None
        | Some cat_picture -> 
            let cat_picture' = { cat_picture with price = cat_picture.price * 2 } in
            match cat_picture.owner with
            | None -> 
                (match remove_credits_from_member cat_picture.price buyer with
                 | None -> None
                 | Some buyer' ->
                     Some {
                       members = replace_member buyer' auction.members ;
                       cat_pictures = replace_cat_picture cat_picture'
                       auction.cat_pictures ;
                     })
            | Some seller_name -> 
                match find_member_by_name seller_name auction.members with
                | None -> None
                | Some seller ->
                    match transfer_credits cat_picture.price buyer seller with
                    | None -> None
                    | Some (buyer', seller') -> 
                        Some {
                          members = replace_member buyer' (replace_member seller' auction.members) ;
                          cat_pictures = replace_cat_picture cat_picture'
                          auction.cat_pictures ;
                        }
;;

let starting_cat_picture_price = 100 ;;

let sell_cat_picture : string * string -> string -> auction -> auction option =
  fun member_name cat_picture_name auction ->
    match find_member_by_name member_name auction.members with
    | None -> None
    | Some seller ->
        match find_cat_picture_by_name cat_picture_name auction.cat_pictures with
        | None -> None
        | Some cat_picture ->
            let cat_picture' = { cat_picture with price = starting_cat_picture_price } in
            let seller' = add_credits_to_member (starting_cat_picture_price / 2) seller in
            Some {
              members = replace_member seller' auction.members ;
              cat_pictures = replace_cat_picture cat_picture'
              auction.cat_pictures ;
            }
;;

