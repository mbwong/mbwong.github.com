open Helpers;;
open Auction;;

(* infrastructure *)

let load_state : unit -> auction option = undefined () ;;
let save_state : auction -> unit = undefined () ;;
let run_command : string list -> unit = undefined () ;;

