let undefined : unit -> 'a = fun () -> failwith "undefined" ;;


